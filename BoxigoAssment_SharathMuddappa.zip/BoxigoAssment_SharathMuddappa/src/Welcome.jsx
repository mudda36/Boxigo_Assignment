import React from 'react';

const Welcome = () => {
  return (
    <div>
      <h1>Home page</h1>
    </div>
  );
};

export default Welcome;